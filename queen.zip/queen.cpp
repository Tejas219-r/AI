#include <iostream>
using namespace std;
class queen
{
public:
    int position[20];
    int count = 0;
    int place(int r, int c);
    int nqueen(int r, int n);
    int display(int n);
};
int queen::place(int r, int c)
{
    for (int i = 1; i < r; i++)
    {
        if (position[i] == c || abs(position[i] - c) == abs(i - r))
        {
            return 0;
        }
    }
    return 1;
}
int queen::nqueen(int r, int n)
{
    for (int c = 1; c <= n; c++)
    {
        if (place(r, c))
        {
            position[r] = c;
            if (r == n)
            {
                display(n);
            }
            else
            {
                nqueen(r + 1, n);
            }
        }
    }
    return 0;
}
int queen::display(int n)
{
    cout << "\n\nSolution\n\n"
         << ++count;
    for (int i = 1; i <= n; i++)
    {
        cout << "\t" << i;
    }
    for (int i = 1; i <= n; i++)
    {
        cout << "\n"
             << i;

        for (int j = 1; j <= n; j++)
        {
            if (position[i] == j)
            {
                cout << "\t Q";
            }
            else
            {
                cout << "\t -";
            }
        }
    }
    return 0;
}
int main()
{
    queen p;
    int n;
    cout << "enter the number of queen=";
    cin >> n;
    p.nqueen(1, n);

    return 0;
}