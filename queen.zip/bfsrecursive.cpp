#include <iostream>
#include <queue>
#include <stack>
using namespace std;

struct node
{
    string c;
    node *next;
};
class graphhh
{
public:
    int x;
    graphhh()
    {
        cout << "Enter number of nodes=";
        cin >> x;
    }
    node *head[10];
    void initial();
    void create();
    void displayy();
    void bfs();
    void dfs();
    void dfsre(int index, int visited[]);
};

void graphhh::initial()
{

    for (int i = 0; i < x; i++)
    {
        head[i] = new node;
        head[i]->c = 'x';
        head[i]->next = NULL;
    }
}

void graphhh::create()
{
    int n;
    node *temp;
    for (int i = 0; i < x; i++)
    {
        cout << "Enter the node : ";
        cin >> head[i]->c;
        cout << "Enter number of nodes conected to =" << head[i]->c << " ";
        cin >> n;
        for (int j = 0; j < n; j++)
        {
            node *nnode = new node;
            cout << "Enter the subnode :=";
            cin >> nnode->c;
            nnode->next = NULL;
            temp = head[i];
            while (temp->next != NULL)
                temp = temp->next;

            temp->next = nnode;
        }
    }
}

void graphhh::displayy()
{
    node *temp;
    for (int i = 0; i < x; i++)
    {
        cout << head[i]->c;
        temp = head[i];
        temp = temp->next;
        cout << ": ";
        while (temp != NULL)
        {
            cout << temp->c;
            temp = temp->next;
        }
        cout << endl;
    }
}

void graphhh::bfs()
{
    int visited[10], i;
    node *temp;
    queue<string> q1;
    string a;
    for (i = 0; i < x; i++)
    {
        visited[i] = 0;
    }
    q1.push(head[0]->c);
    visited[0] = 1;

    while (!q1.empty())
    {
        a = q1.front();
        q1.pop();
        cout << a;

        i = 0;
        while (a != head[i]->c)
        {
            i++;
        }
        temp = head[i];
        while (temp != NULL)
        {
            i = 0;
            while (temp->c != head[i]->c)
            {
                i++;
            }
            if (visited[i] == 0)
            {
                q1.push(head[i]->c);
                visited[i] = 1;
            }
            temp = temp->next;
        }
    }
    cout << endl;
}

void graphhh::dfsre(int index, int visited[])
{
    visited[index] = 1;
    cout << head[index]->c;

    node *temp = head[index]->next;
    while (temp != NULL)
    {
        int i = 0;
        while (temp->c != head[i]->c)
        {
            i++;
        }
        if (!visited[i])
        {
            dfsre(i, visited);
        }
        temp = temp->next;
    }
}

void graphhh::dfs()
{
    int visited[10] = {0};
    dfsre(0, visited);
}

int main()
{
    graphhh o;
    o.initial();
    o.create();
    o.displayy();
    cout << "BFS" << endl;
    o.bfs();
    cout << "DFS" << endl;
    o.dfs();
    return 0;
}
