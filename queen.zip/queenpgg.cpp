#include <iostream>
using namespace std;

class Queen {
public:
    int positions[20]; // Increase the array size to accommodate larger problem sizes
    int count = 0;
    int place(int row, int col);
    int nQueen(int row, int size);
    int display(int size);
};
int Queen::place(int row, int col) {
    for (int i = 1; i < row; i++) {
        if (positions[i] == col || abs(positions[i] - col) == abs(i - row)) {
            return 0;
        }
    }
    return 1;
}
int Queen::nQueen(int row, int size) {
    for (int col = 1; col <= size; col++) {
        if (place(row, col)) {
            positions[row] = col;
            if (row == size) {
                display(size);
            } else {
                nQueen(row + 1, size);
            }
        }
    }
    return 0;
}

int Queen::display(int size) {
    cout << "\n\nSolution\n\n" << ++count;
    for (int i = 1; i <= size; i++) {
        cout << "\t" << i;
    }
    for (int i = 1; i <= size; i++) {
        cout << "\n" << i;
        for (int j = 1; j <= size; j++) {
            if (positions[i] == j) {
                cout << "\t Q";
            } else {
                cout << "\t -";
            }
        }
    }
    return 0;
}

int main() {
    Queen q;
    int size;
    cout << "------------------\n";
    cout << " N-Queen Solution \n";
    cout << "------------------\n";
    cout << " Enter the number of Queens: ";
    cin >> size;
    q.nQueen(1, size);

    return 0;
}
