#include <iostream>
#include <queue>
#include <stack>
using namespace std;

struct node
{
    string c;
    node *next;
};

class graphhh
{
public:
    int x;
    graphhh()
    {
        cout << "Enter number of nodes=";
        cin >> x;
    }
    node *head[10];
    void initial();
    void create();
    void displayy();
    void bfs();
    void dfs();
};

void graphhh::initial()
{

    for (int i = 0; i < x; i++)
    {
        head[i] = new node;
        head[i]->c = 'x';
        head[i]->next = NULL;
    }
}

void graphhh::create()
{
    int n;
    node *temp;
    for (int i = 0; i < x; i++)
    {
        cout << "Enter the node : ";
        cin >> head[i]->c;
        cout << "Enter number of nodes conected to =" << head[i]->c << " ";
        cin >> n;
        for (int j = 0; j < n; j++)
        {
            node *nnode = new node;
            cout << "Enter the subnode :=";
            cin >> nnode->c;
            nnode->next = NULL;
            temp = head[i];
            while (temp->next != NULL)
                temp = temp->next;

            temp->next = nnode;
        }
    }
}

void graphhh::displayy()
{
    node *temp;
    for (int i = 0; i < x; i++)
    {
        cout << head[i]->c;
        temp = head[i];
        temp = temp->next;
        cout << ": ";
        while (temp != NULL)
        {
            cout << temp->c;
            temp = temp->next;
        }
        cout << endl;
    }
}

void graphhh::bfs()
{
    int visited[10], i;
    node *temp;
    queue<string> q1;
    string a;
    for (i = 0; i < x; i++)
    {
        visited[i] = 0;
    }
    q1.push(head[0]->c);
    visited[0] = 1;

    while (!q1.empty())
    {
        a = q1.front();
        q1.pop();
        cout << a;

        i = 0;
        while (a != head[i]->c)
        {
            i++;
        }
        temp = head[i];
        while (temp != NULL)
        {
            i = 0;
            while (temp->c != head[i]->c)
            {
                i++;
            }
            if (visited[i] == 0)
            {
                q1.push(head[i]->c);
                visited[i] = 1;
            }
            temp = temp->next;
        }
        // cout<<endl;
    }
    cout << endl;
}

void graphhh::dfs()
{
    node *temp;
    string a;
    int visited[10], i;
    for (i = 0; i < x; i++)
    {
        visited[i] = 0;
    }
    stack<string> s1;
    s1.push(head[0]->c);
    visited[0] = 1;
    cout << s1.top();
    a = s1.top();
    while (!s1.empty())
    {
        i = 0;
        while (a != head[i]->c){
            i++;
        }
        temp = head[i];
        while (temp != NULL)
        {
            int j = 0;
            while (temp->c != head[j]->c)
            {
                j++;
            }
            if (visited[j] == 0)
            {
                s1.push(head[j]->c);
                visited[j] = 1;
                cout << s1.top();
                temp = head[j];
            }
            temp = temp->next;
        }
        s1.pop();
        a = s1.top();
    }
}
int main()
{
    graphhh o;
    o.initial();
    o.create();
    o.displayy();
    cout << "BFS" << endl;
    o.bfs();
    cout << "DFS" << endl;
    o.dfs();
    return 0;
}